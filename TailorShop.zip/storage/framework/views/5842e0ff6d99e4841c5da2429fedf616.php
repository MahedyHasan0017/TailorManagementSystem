

<?php $__env->startSection('content'); ?>
<div class="page-wrapper">

    <div class="page-breadcrumb">
        <div class="row">
            <div class="col-12 d-flex no-block align-items-center">
                <h4 class="page-title">employee single</h4>
                <div class="ms-auto text-end">
                    <nav aria-label="breadcrumb">
                        <ol class="breadcrumb">
                            <li class="breadcrumb-item"><a href="#">Home</a></li>
                            <li class="breadcrumb-item active" aria-current="page">Library</li>
                        </ol>
                    </nav>
                </div>
            </div>
        </div>
    </div>

    <div class="container-fluid">

        <div class="accordion" id="accordionExample">
            <div class="row">
                <div class="col-12">
                    <h2>here is all permissions for employees</h2>
                </div>
                <div class="col-12">
                    <div>
                        Please assign the permissions for 
                    </div>
                    <div>
                        employee name : <?php echo e($employee->full_name); ?>

                    </div>
                    <div>
                        employee id : <?php echo e($employee->employee_id); ?>

                    </div>
                    <div>
                        employee mobile number : <?php echo e($employee->mobile_number); ?>

                    </div>
                    <div>
                        vendor mobile number : <?php echo e($employee->vendor_mobile); ?>

                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-md-6 mt-3">

                    <form method="post" action="<?php echo e(route('vendor.employee.submit.permissions')); ?>" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>

                        <input type="text" hidden value=<?php echo e($id); ?> name="employee_id" id="employee_id">

                        <div class="form-group">
                            <label><strong>Permission Name :</strong></label>

                            <div>

                                <label><input type="checkbox" name="permission_name[]" value="পোষাক অর্ডার"> পোষাক অর্ডার</label>
                            </div>
                            <div>

                                <label><input type="checkbox" name="permission_name[]" value="কর্মচারী পরিচালনা"> কর্মচারী পরিচালনা</label>
                            </div>
                            <div>

                                <label><input type="checkbox" name="permission_name[]" value="মেসেজ প্রদান"> মেসেজ প্রদান</label>
                            </div>
                            <div>

                                <label><input type="checkbox" name="permission_name[]" value="আয় ব্যয় হিসাব"> আয় ব্যয় হিসাব</label>
                            </div>
                            <div>

                                <label><input type="checkbox" name="permission_name[]" value="রিপোর্ট "> রিপোর্ট </label>
                            </div>
                            <div>

                                <label><input type="checkbox" name="permission_name[]" value="সেটিংস "> সেটিংস </label>
                            </div>
                        </div>

                        <div class="form-group">
                            <button type="submit" class="btn btn-success btn-sm w-full" style="width: 100%;">Save</button>
                        </div>
                    </form>




                </div>

                <div class="col-md-6 mt-3">
                    <h4>Permissions you have already given.</h4>
                    <?php $__currentLoopData = $persmissions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $persmission): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div>
                            <?php echo e($persmission->permission_name); ?>

                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>



            </div>
        </div>

    </div>
    <?php $__env->stopSection(); ?>


    

<?php echo $__env->make('.vendor.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Rizwan\TailorShop\resources\views/vendor/permissions/employee/employee_single.blade.php ENDPATH**/ ?>