

<?php $__env->startSection('content'); ?>
    <div class="page-wrapper">

        <div class="page-breadcrumb">
            <div class="row">
                <div class="col-12 d-flex no-block align-items-center">
                    <h4 class="page-title">Approved Payment List</h4>
                    <div class="ms-auto text-end">
                        <nav aria-label="breadcrumb">
                            <ol class="breadcrumb">
                                <li class="breadcrumb-item"><a href="#">Home</a></li>
                                <li class="breadcrumb-item active" aria-current="page">Library</li>
                            </ol>
                        </nav>
                    </div>
                </div>
            </div>
        </div>

        <div class="container-fluid">

            <div class="accordion" id="accordionExample">

                <div class="row">

                    <div class="mt-3">

                        <table id="example" class="display" style="width:100%">
                            <thead class="accordion__heading">
                                <tr>
                                    <th>Vendor Name</th>
                                    <th>Mobile Number</th>
                                    <th>Transection Id</th>
                                    <th>Amount</th>
                                    <th>Num of Tailor</th>
                                    <th>Time Span</th>
                                    
                                </tr>
                            </thead>
                            <tbody>

                                <?php $__currentLoopData = $payments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $payment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($payment->vendor_identity); ?></td>
                                        <td><?php echo e($payment->mobile_number); ?></td>
                                        <td><?php echo e($payment->transection_id); ?></td>
                                        <td><?php echo e($payment->total_amount); ?></td>
                                        <td><?php echo e($payment->number_of_tailor); ?></td>
                                        <td><?php echo e($payment->time_span); ?></td>

                                        


                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            </tbody>

                        </table>


                    </div>
                </div>
            </div>


        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('.superAdmin.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Rizwan\TailorShop\resources\views/superAdmin/payment/approved.blade.php ENDPATH**/ ?>