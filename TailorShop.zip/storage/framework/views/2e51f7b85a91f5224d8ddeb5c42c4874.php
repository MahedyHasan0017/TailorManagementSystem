


<?php echo $__env->make('.vendor/common_components/header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php echo $__env->make('.vendor/common_components/sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php echo $__env->yieldContent('content'); ?>  

<?php echo $__env->make('./vendor.common_components.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php echo $__env->yieldPushContent('scripts'); ?>

<?php /**PATH C:\Users\Rizwan\TailorShop\resources\views/vendor/main.blade.php ENDPATH**/ ?>