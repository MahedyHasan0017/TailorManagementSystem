

<?php $__env->startSection('content'); ?>
    <div class="page-wrapper">

        <div class="page-breadcrumb">
            <div class="row">
                <div class="col-12 d-flex no-block align-items-center">
                    <h4 class="page-title">Admin লিস্ট</h4>
                    <div class="ms-auto text-end">
                        <nav aria-label="breadcrumb">
                            <ol class="breadcrumb">
                                <li class="breadcrumb-item"><a href="#">Home</a></li>
                                <li class="breadcrumb-item active" aria-current="page">Library</li>
                            </ol>
                        </nav>
                    </div>
                </div>
            </div>
        </div>

        <div class="container-fluid">


            <div class="accordion" id="accordionExample">

                <div class="row">

                    <div class="mt-3">

                        <table id="example" class="display" style="width:100%">
                            <thead class="accordion__heading">
                                <tr>
                                    <th>admin id</th>
                                    <th>admin name</th>
                                    <th>admin mobile number/email</th>
                                    <th>view details</th>

                                </tr>
                            </thead>
                            <tbody>

                                <?php $__currentLoopData = $admins; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $admin): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($admin->id); ?></td>
                                        <td><?php echo e($admin->name); ?></td>
                                        <th><?php echo e($admin->email); ?></th>

                                        <td>

                                            <a href="<?php echo e(route('auth.update.manager.from.admin', ['id' => $admin->id])); ?>"
                                                class="btn btn-primary">update to manager</a>

                                            <?php if(Auth::guard('admin')->user()->status == 5): ?>
                                                <a href="<?php echo e(route('auth.delete.superadmin.from.admin', ['id' => $admin->id])); ?>"
                                                    class="btn btn-primary">Delete</a>
                                            <?php endif; ?>


                                        </td>


                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            </tbody>

                        </table>


                    </div>
                </div>
            </div>

        </div>
    <?php $__env->stopSection(); ?>

<?php echo $__env->make('.superAdmin.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Rizwan\TailorShop\resources\views/superAdmin/admin/admin_list.blade.php ENDPATH**/ ?>