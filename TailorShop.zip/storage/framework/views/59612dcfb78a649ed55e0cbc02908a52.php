

<?php $__env->startSection('content'); ?>
    <div class="page-wrapper">

        <div class="page-breadcrumb">
            <div class="row">
                <div class="col-12 d-flex no-block align-items-center">
                    <h4 class="page-title">Add Dress Information</h4>
                    <div class="ms-auto text-end">
                        <nav aria-label="breadcrumb">
                            <ol class="breadcrumb">
                                <li class="breadcrumb-item"><a href="#">Home</a></li>
                                <li class="breadcrumb-item active" aria-current="page">Library</li>
                            </ol>
                        </nav>
                    </div>
                </div>
            </div>
        </div>

        <div class="container-fluid">
            <div class="row">
                <div class="col-md-6">
                    <form
                        action="<?php echo e(route('admin.settings.dress.info.submit', ['id' => Auth::guard('admin')->user()->mobile_number])); ?>"
                        method="post">
                        <?php echo csrf_field(); ?>
                        <div class="form-group">
                            <input type="text" class="form-control" name='dress_name' id='dress_name'
                                placeholder="Enter Dress Name" />
                            <div>
                                <?php $__errorArgs = ['dress_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div style="color: red ; font-weight : bold">
                                        <?php echo e($message); ?>

                                    </div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>
                        <div class="form-group">
                            <input type="text" class="form-control" name="dress_price" id='dress_price'
                                placeholder="Enter Dress Price" />
                            <div>
                                <?php $__errorArgs = ['dress_price'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div style="color: red ; font-weight : bold">
                                        <?php echo e($message); ?>

                                    </div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>
                        <div class="form-group">
                            <input type="text" class="form-control" name="dress_wages" id='dress_wages'
                                placeholder="Enter Dress Wages" />
                            <div>
                                <?php $__errorArgs = ['dress_wages'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div style="color: red ; font-weight : bold">
                                        <?php echo e($message); ?>

                                    </div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>
                        <div class="form-group">
                            <input type="text" class="form-control" name="dress_type" id='dress_type'
                                placeholder="Enter Dress Type" />
                            <div>
                                <?php $__errorArgs = ['dress_type'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div style="color: red ; font-weight : bold">
                                        <?php echo e($message); ?>

                                    </div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>
                        <div class="form-group">
                            

                            <select name="dress_part_type" id="dress_part_type" class="form-control">
                                <option value="upper_part">Upper Part</option>
                                <option value="lower_part">Lower Part</option>
                            </select>

                        </div>
                        <div>
                            <?php if(Auth::guard('admin')->user() != null): ?>
                                <input type="text" name="admin_id" id="admin_id"
                                    value="<?php echo e(Auth::guard('admin')->user()->mobile_number); ?>" hidden>
                            <?php endif; ?>
                        </div>
                        <div>
                            <?php if(Auth::guard('vendor')->user() != null): ?>
                                <input type="text" name="vendor_id" id="vendor_id"
                                    value="<?php echo e(Auth::guard('vendor')->user()->mobile_number); ?>" hidden>
                            <?php endif; ?>
                        </div>
                        <div class="form-group">
                            <button class="btn btn-success">
                                Submit
                            </button>
                        </div>

                    </form>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('.superAdmin.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Rizwan\TailorShop\resources\views/superAdmin/settings/cloth_settings.blade.php ENDPATH**/ ?>