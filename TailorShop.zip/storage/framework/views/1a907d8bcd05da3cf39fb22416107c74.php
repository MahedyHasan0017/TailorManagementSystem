<div class="table-responsive table__container">
    <table class="table">
        <thead class="custom_table_heading">
            <tr>
                <th scope="col">পোশাকের নাম <span style="color:red">*</span></th>
                <th scope="col">সংখ্যা <span style="color:red">*</span></th>
                <th scope="col">মূল্য</th>
                <th scope="col">মোট মূল্য</th>
            </tr>
        </thead>
        <tbody class="custom_table_body custom_table_height">
            <?php $__currentLoopData = $cloth_list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cloth): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td scope="row">
                        <div class="form-check">
                            <input class="form-check-input" type="checkbox" value="<?php echo e($cloth->cloth_name); ?>"
                                name="cloth_full_name[]" id="cloth_full_name[]">
                            <label class="form-check-label" for="cloth_full_name[]">
                                <?php echo e($cloth->cloth_name); ?>

                            </label>
                        </div>
                    </td>
                    <td>
                        <div class="">
                            <input type="number" class="form-control" name="number_of_cloth<?php echo e($loop->index); ?>" min=1
                                id="number_of_cloth<?php echo e($loop->index); ?>" value="1"
                                onchange="updateTotal(<?php echo e($loop->index); ?>)">
                        </div>
                    </td>
                    <td>
                        <div class="">
                            <input type="text" class="form-control" name="price_of_cloth<?php echo e($loop->index); ?>"
                                id="price_of_cloth<?php echo e($loop->index); ?>" value="<?php echo e($cloth->cloth_price); ?>" readonly>
                        </div>
                    </td>
                    <td>
                        <div class="">
                            <input type="text" class="form-control" name="total_price_of_cloth<?php echo e($loop->index); ?>"
                                id="total_price_of_cloth<?php echo e($loop->index); ?>">
                        </div>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        </tbody>
        <tfoot class="custom_table_footer">

            <th scope="row">@twitter</th>
            <td></td>
            <td>cell-3</td>
            <td scope="col">cell 2</td>
        </tfoot>
    </table>
</div>

<?php /**PATH C:\Users\Rizwan\TailorShop\resources\views/superAdmin/cloth_order/cloth_table.blade.php ENDPATH**/ ?>