

<?php $__env->startSection('content'); ?>
    <div class="page-wrapper">

        <div class="page-breadcrumb">
            <div class="row">
                <div class="col-12 d-flex no-block align-items-center">
                    <h4 class="page-title">Payment Request Details</h4>
                    <div class="ms-auto text-end">
                        <nav aria-label="breadcrumb">
                            <ol class="breadcrumb">
                                <li class="breadcrumb-item"><a href="#">Home</a></li>
                                <li class="breadcrumb-item active" aria-current="page">Library</li>
                            </ol>
                        </nav>
                    </div>
                </div>
            </div>
        </div>

        <div class="container-fluid">

            <div class="accordion" id="accordionExample">
                <div class="row">
                    <div class="col-12">
                        <div>
                            <h3>
                                Vendor Name : <?php echo e($transection_info->vendor_identity); ?>

                            </h3>
                            <div>
                                Vendor Mobile : <?php echo e($transection_info->vendor_mobile_number); ?>

                            </div>
                            <div>
                                Payment Number : <?php echo e($transection_info->mobile_number); ?>

                            </div>
                            <div>
                                Transection Id : <?php echo e($transection_info->transection_id); ?>

                            </div>
                            <div>
                                Total Amount : <?php echo e($transection_info->total_amount); ?>

                            </div>
                            <div>
                                Number Of Tailor Vendor Wants To Be Added : <?php echo e($transection_info->number_of_tailor); ?>

                            </div>
                            <div>
                                Active Time Span For each employee <?php echo e($transection_info->time_span[0]); ?> <?php if($transection_info->time_span[0] > 1): ?>
                                    months
                                <?php else: ?>
                                    month
                                <?php endif; ?>
                            </div>
                            <div> 	
                                
                                <form action="<?php echo e(route('admin.payments.request.submit.store')); ?>" method="post">
                                    <?php echo csrf_field(); ?>
                                    <div>
                                        <input type="text" hidden name="payment_id" value="<?php echo e($transection_info->payment_request_id); ?>" readonly>
                                    </div> 
                                    <div>
                                        <input type="text" hidden name="vendor_id" value="<?php echo e($transection_info->vendor_mobile_number); ?>" readonly>
                                    </div>
                                    <div>
                                        <input type="text" hidden name='number_of_tailor' value="<?php echo e($transection_info->number_of_tailor); ?>" readonly>
                                    </div>
                                    <div>
                                        <input type="text" hidden name="time_span" value="<?php echo e($transection_info->time_span); ?>" readonly>
                                    </div>

                                    <button class="btn btn-success">
                                        Activate
                                    </button>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('.superAdmin.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Rizwan\TailorShop\resources\views/superAdmin/payment/payment_approve_confirm.blade.php ENDPATH**/ ?>