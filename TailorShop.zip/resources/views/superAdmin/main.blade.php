@include('.superAdmin/common_components/header')


@include('.superAdmin/common_components/sidebar')

@yield('content')  


@include('./superAdmin.common_components.footer')
@stack('scripts')



