
@include('.employee/common_components/header')

@include('.employee/common_components/sidebar')

@yield('content')


@include('./employee.common_components.footer')


@stack('scripts')
