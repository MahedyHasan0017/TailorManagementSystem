<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class BotamForPantController extends Controller
{
    //
}
