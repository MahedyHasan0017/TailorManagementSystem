<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class PocketForPanjabiController extends Controller
{
    //
}
