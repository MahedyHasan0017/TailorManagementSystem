<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class ClothOrderController extends Controller
{
    //
}
