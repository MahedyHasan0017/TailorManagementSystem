<?php

function en2bn($number)
{
    $bn = ['১', '২', '৩', '৪', '৫', '৬', '৭', '৮', '৯', '০'];
    $en = ['1', '2', '3', '4', '5', '6', '7', '8', '9', '0'];
    return str_replace($en, $bn, $number);
}


function bn2en($number)
{
    $bn = ['১', '২', '৩', '৪', '৫', '৬', '৭', '৮', '৯', '০'];
    $en = ['1', '2', '3', '4', '5', '6', '7', '8', '9', '0'];
    return str_replace($bn, $en, $number);
}
